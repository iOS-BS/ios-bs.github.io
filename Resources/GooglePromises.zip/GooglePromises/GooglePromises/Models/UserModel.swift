//
//  UserModel.swift
//  GooglePromises
//
//  Created by BeetSoft on 7/30/19.
//  Copyright © 2019 Beetsoft CO., LTD. All rights reserved.
//

import UIKit

struct UserModel: Codable {
    let token: String?
    let error: String?
}
