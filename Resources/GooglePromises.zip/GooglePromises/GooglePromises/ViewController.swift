//
//  ViewController.swift
//  GooglePromises
//
//  Created by BeetSoft on 7/30/19.
//  Copyright © 2019 Beetsoft CO., LTD. All rights reserved.
//

import Promises
import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        APIHelper.login(userName: "eve.holt@reqres.in", password: "cityslicka").then { token in
            return APIHelper.getUserList(token: token.token ?? "Error(\(token.error!))")
        }.then { userList in
            print(userList)
        }
//        all(
//            APIHelper.login(userName: "eve.holt@reqres.in", password: "cityslicka"),
//            APIHelper.getUserList(token: "")
//        ).then { login, list in
//            print(login.token, list)
//        }.always {
//            print("all request done")
//        }
    }
}
