//
//  APIHelper.swift
//  GooglePromises
//
//  Created by BeetSoft on 7/30/19.
//  Copyright © 2019 Beetsoft CO., LTD. All rights reserved.
//

import Promises
import UIKit

private let HOST = "https://reqres.in"

enum APIError: Error {
    case InvalidURL
    case UnknownError
    case InvalidJson
}

enum apiURL: String {
    case login = "/api/login"
    case userList = "/api/users?page=2"
    func getURL() -> String {
        return HOST + rawValue
    }
}

class APIHelper {
    class func login(userName: String, password: String) -> Promise<UserModel> {
        return Promise<UserModel>({ response, reject in
            guard let url = URL(string: apiURL.login.getURL()) else {
                reject(APIError.InvalidURL)
                return
            }
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            let dataBody = "email=\(userName)&password=\(password)"
            request.httpBody = dataBody.data(using: .utf8)
            let session = URLSession.shared.dataTask(with: request, completionHandler: { data, _, err in
                guard let dataResponse = data else {
                    reject(err ?? APIError.UnknownError)
                    return
                }
                do {
                    let user = try newJSONDecoder().decode(UserModel.self, from: dataResponse)
                    response(user)
                } catch {
                    reject(APIError.InvalidJson)
                }
            })
            session.resume()
        })
    }

    class func getUserList(token: String) -> Promise<UserListModel> {
        print(token)
        return Promise<UserListModel>({ fullfill, reject in
            guard let url = URL(string: apiURL.userList.getURL()) else {
                reject(APIError.InvalidURL)
                return
            }
            let session = URLSession.shared.dataTask(with: url, completionHandler: { data, _, err in
                guard let dataResponse = data else {
                    reject(err ?? APIError.UnknownError)
                    return
                }
                do {
                    let userList = try newJSONDecoder().decode(UserListModel.self, from: dataResponse)
                    fullfill(userList)
                } catch {
                    reject(APIError.InvalidJson)
                }
            })
            session.resume()
        })
    }

    // MARK: - Helper functions for creating encoders and decoders

    class func newJSONDecoder() -> JSONDecoder {
        let decoder = JSONDecoder()
        if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
            decoder.dateDecodingStrategy = .iso8601
        }
        return decoder
    }

    class func newJSONEncoder() -> JSONEncoder {
        let encoder = JSONEncoder()
        if #available(iOS 10.0, OSX 10.12, tvOS 10.0, watchOS 3.0, *) {
            encoder.dateEncodingStrategy = .iso8601
        }
        return encoder
    }
}
